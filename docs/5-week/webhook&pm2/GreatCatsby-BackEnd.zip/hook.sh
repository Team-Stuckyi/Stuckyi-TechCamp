#!/bin/bash

# DIRECTORY TO THE REPOSITORY
REPOSITORY="/home/xeros/ServerProccess/GreatCatsby-BackEnd"

cd $REPOSITORY

git pull