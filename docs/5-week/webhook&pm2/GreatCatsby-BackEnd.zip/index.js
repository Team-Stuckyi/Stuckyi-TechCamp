const express = require('express')
const app = express()
const host = "localhost"
const port = 3000

console.log("+== Server Start ==+");
console.log("Server started at: " + new Date());
console.log("Server IP Address: " + host);
console.log("Server Port: " + port);

app.get('/', (req, res) => {
    console.log(`[${new Date()}] Request at ${req.ip}`);
    res.send('Last Test!')
})

app.listen(port, () => {
  console.log(`Example app listening on port ${port}`)
})